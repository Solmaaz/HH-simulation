function b=bn1(v1) %Beta for variable n
    b=0.125*exp(-(v1+60)/80);
end