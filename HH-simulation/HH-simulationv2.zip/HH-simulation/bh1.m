function b =bh1(v1) %beta value for variable h
    b=1/(1+exp(-(0.1)*(v1+30)));
end