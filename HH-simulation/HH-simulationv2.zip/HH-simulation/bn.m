function b=bn(v) %Beta for variable n
    b=0.125*exp(-(v+60)/80);
end