function a=an1(v1)%Alpha for variable n
    a=0.01*(v1+50)/(1-exp(-(v1+50)/10));
end