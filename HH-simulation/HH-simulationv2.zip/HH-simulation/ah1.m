function a=ah1(v1) %Alpha value for variable h
    a=0.07*exp(-0.05*(v1+60));
end