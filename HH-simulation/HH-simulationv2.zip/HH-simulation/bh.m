function b =bh(v) %beta value for variable h
    b=1/(1+exp(-(0.1)*(v+30)));
end