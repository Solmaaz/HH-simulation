clc;
clear;
Cm = 1;%microFarad
dt = 0.01;
t=0:dt:50;
f=10;
I1=2;

ENa=55.17;  % mv Na reversal potential
EK=-72.14; % mv K reversal potential
El=-49.42; % mv Leakage reversal potential
Esyn=-70;
gbarNa=120; % mS/cm^2 Na conductance
gbarK=36; % mS/cm^2 K conductance
gbarl=0.3; % mS/cm^2 Leakage conductance
gsyn=0;
I2=whitegaussiannoise;
td=20; %ms decay time
tr=5; %ms rise time
tl=0; % ms latency time
mt=10; %ms membrane time cte
V(1)=-60; % Initial Membrane voltage
m(1)=am(V(1))/(am(V(1))+bm1(V(1))); 
% Initial m-value
n(1)=an(V(1))/(an(V(1))+bn(V(1))); 
% Initial n-value
h(1)=ah(V(1))/(ah(V(1))+bh(V(1))); 
% Initial h-value

V1(1)=-60; % Initial Membrane voltage
m1(1)=am1(V1(1))/(am1(V1(1))+bm2(V1(1))); 
% Initial m-value
n1(1)=an1(V1(1))/(an1(V1(1))+bn1(V1(1))); 
% Initial n-value
h1(1)=ah1(V1(1))/(ah1(V1(1))+bh1(V1(1))); 
% Initial h-value
s(1)=am(V1(1))/(am(V1(1))+bm1(V1(1)));
Isyn(1)=0;

for i=1:length(t)-1
    
    %Euler method to find the next m/n/h value
     % I(i);pulse
    m(i+1)=m(i)+dt*((am(V(i))*(1-m(i)))-(bm1(V(i))*m(i))); 
    n(i+1)=n(i)+dt*((an(V(i))*(1-n(i)))-(bn(V(i))*n(i)));
    h(i+1)=h(i)+dt*((ah(V(i))*(1-h(i)))-(bh(V(i))*h(i)));
    gNa=gbarNa*m(i)^3*h(i);
    gK=gbarK*n(i)^4;
    gl=gbarl;
    INa=gNa*(V(i)-ENa);
    IK=gK*(V(i)-EK);
    Il=gl*(V(i)-El);
    %Euler method to find the next voltage value
    V(i+1)=V(i)+(dt)*((1/Cm)*(I1-(INa+IK+Il)))+sqrt(dt)*(1/Cm)*I2(i);
    
     m1(i+1)=m1(i)+dt*((am1(V1(i))*(1-m1(i)))-(bm2(V1(i))*m1(i))); 
    n1(i+1)=n1(i)+dt*((an1(V1(i))*(1-n1(i)))-(bn1(V1(i))*n1(i)));
    h1(i+1)=h1(i)+dt*((ah1(V1(i))*(1-h1(i)))-(bh1(V1(i))*h1(i)));
    s(i+1)=((mt/(td-tr))*(exp(-((i)-tl)/td)-exp(-((i)-tl)/tr)));
    gNa1=gbarNa*m1(i)^3*h1(i);
    gK1=gbarK*n1(i)^4;
    gl=gbarl;
    if (V>30)
    Isyn(i+1)=gsyn*s(i)*(V1(i)-Esyn)*dt+Isyn(i);
    else 
        Isyn(i+1)=0;
    end
    INa1=gNa1*(V1(i)-ENa);
    IK1=gK1*(V1(i)-EK);
    Il1=gl*(V1(i)-El);
    %Euler method to find the next voltage value
    V1(i+1)=V1(i)+dt*(1/Cm)*Isyn(i)+(dt)*((1/Cm)*(I1-(INa1+IK1+Il1)));
end

%Store variables for graphing later
FI=Isyn;
FE=V;
FE1=V1;
FEm=m;
FEn=n;
FEh=h;

%Plot the functions
figure();
plot(t,FI);
legend('Forward Euler');
xlabel('Time (ms)');
ylabel('voltage (mV)');
title('Voltage  Change for second Hodgkin-Huxley Model');
figure();
plot(t,FE);
legend('Forward Euler');
xlabel('Time (ms)');
ylabel('Voltage (mV)');
title('Voltage Change for first Hodgkin-Huxley Model');
%hold on
%plot(FEm,FEn);