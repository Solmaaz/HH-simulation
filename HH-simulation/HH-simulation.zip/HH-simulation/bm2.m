function b=bm2(v1) %Beta for variable m
    b=4.0*exp(-0.0556*(v1+60));
end