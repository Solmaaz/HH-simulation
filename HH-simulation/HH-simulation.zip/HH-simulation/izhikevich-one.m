% 1) i n i t i a l i z e pa r ame t e r s
dt=0.5;
d=8;
a=0.02;
c=?65;
 b=0.2;
 T=ceil(1000/dt);

 % 2) r e s e r v e memory
 v=zeros(T,1);
 u=zeros(T,1);
v(1)=?70; % r e s t i n g p o t e n t i a l
u(1)= ?14; % s t e a d y s t a t e

%3) f o r?l o o p o v e r t ime
 for t=1:T?1;
 %3 . 1 ) ge t i n p u t
 if t*dt>200 && t*dt<700
Iapp=7;
 else
Iapp=0;
end
if v(t)<35
 %3 . 2 ) update ODE
dv=(0.04*v(t)+5)*v(t)+140?u(t);
v(t+1)=v(t)+(dv+Iapp)*dt;
du=a*(b*v(t)?u(t));
u(t+1)=u(t)+dt*du;
else
%3 . 3 ) s p i k e !
v(t)=35;
v(t+1)=c;
u(t+1)=u(t)+d;
end
end
% 4) p l o t v o l t a g e t r a c e
plot((0:T?1)*dt,v,�b�);
xlabel(�Time[ms]�);
ylabel(�Membrane voltage[mV]�);