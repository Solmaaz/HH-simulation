function I=whitegaussiannoise;
I=wgn(1,10000,5);
%plot(I);
end