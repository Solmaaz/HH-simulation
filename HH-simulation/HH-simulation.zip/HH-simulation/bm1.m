function b=bm1(v) %Beta for variable m
    b=4.0*exp(-0.0556*(v+60));
end