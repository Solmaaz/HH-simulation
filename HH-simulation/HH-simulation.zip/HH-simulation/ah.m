function a=ah(v) %Alpha value for variable h
    a=0.07*exp(-0.05*(v+60));
end