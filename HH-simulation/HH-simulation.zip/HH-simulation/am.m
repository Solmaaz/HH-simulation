function a=am(v) %Alpha for Variable m
    a=0.1*(v+35)/(1-exp(-(v+35)/10));
end